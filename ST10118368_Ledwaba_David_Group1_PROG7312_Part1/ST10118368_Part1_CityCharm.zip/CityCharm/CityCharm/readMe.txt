﻿Tools/Software Needed:

	- Visual Studio
	- MS SQL Server

> User will need to have the tool/software mationed above.

> User will have to download and unzip the project file.

> run and execute script(SQLQueryScript) on MS SQL Server

> open the project(\city_charm\city_charm.sln) using Visual studio 

> install any other tools recommended by MS Visual Studio after projects loads on MS Visual Studio

> *NB* ensure that connection string matches your connection string in the BDAccess.

> run the project after projects loads on MS Visual Studio & installing recommended tools

>Perform the actions that intended for the app.

>if user wants images? there will be a few in the img folder.